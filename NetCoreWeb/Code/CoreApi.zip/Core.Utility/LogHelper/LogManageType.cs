﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Utility.LogHelper
{
    public enum LogManageType
    {
        FileLog,
        DbLog
    }
}
