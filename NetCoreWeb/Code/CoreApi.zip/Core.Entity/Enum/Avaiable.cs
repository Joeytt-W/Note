﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Entity.Enum
{
    /// <summary>
    /// 工位是否可用
    /// </summary>
    public enum Avaiable
    {
        Yes = 1,
        No = 0
    }
}
