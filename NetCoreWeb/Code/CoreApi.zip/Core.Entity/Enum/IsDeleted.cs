﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Entity.Enum
{
    public enum IsDeleted
    {
        Deleted = 1,
        NotDeleted = 0
    }
}
