﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Entity.Enum
{
    /// <summary>
    /// 性别
    /// </summary>
    public enum Gender
    {
        男 = 1,
        女 = 2
    }
}
