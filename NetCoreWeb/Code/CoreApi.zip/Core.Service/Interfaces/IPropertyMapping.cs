﻿namespace Core.Service.Interfaces
{
    public interface IPropertyMapping
    {
        
    }
}