﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Core.Service.Migrations
{
    public partial class Menu2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
