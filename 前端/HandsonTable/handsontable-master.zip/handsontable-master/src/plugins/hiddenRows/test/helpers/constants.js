export const CSS_CLASS_BEFORE_HIDDEN_ROW = 'beforeHiddenRow';
export const CSS_CLASS_AFTER_HIDDEN_ROW = 'afterHiddenRow';
