export const CSS_CLASS_BEFORE_HIDDEN_COLUMN = 'beforeHiddenColumn';
export const CSS_CLASS_AFTER_HIDDEN_COLUMN = 'afterHiddenColumn';
