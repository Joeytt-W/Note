import TextEditor from './textEditor';

/**
 * @private
 * @class NumericEditor
 */
class NumericEditor extends TextEditor {}

export default NumericEditor;
